package com.sultan05.bottomnavigation;

public class Jadwalmodel {
    String hariList, jamList, kelasList, ruangList, mapelList;
//    int idList;
    Jadwalmodel(String hariList, String jamList, String kelasList, String ruangList, String mapelList){
        this.hariList=hariList;
        this.jamList=jamList;
        this.kelasList=kelasList;
        this.ruangList=ruangList;
        this.mapelList=mapelList;
    }
    public String getHariList(){
        return hariList;
    }
//    public void setHariList(String hariList){
//        this.hariList = hariList;
//    }
    public String getJamList(){
        return jamList;
    }
//    public void setJamList(ArrayList jamList){
//        this.jamList = jamList;
//    }
    public String getKelasList(){
        return kelasList;
    }
//    public void setKelasList(ArrayList kelasList){
//        this.kelasList = kelasList;
//    }
    public String getRuangList(){
        return ruangList;
    }
//    public void setRuangList(ArrayList ruangList){
//        this.ruangList = ruangList;
//    }
    public String getMapelList(){
        return mapelList;
    }
//    public void setMapelList(ArrayList mapelList){
//        this.mapelList = mapelList;
//    }
}
