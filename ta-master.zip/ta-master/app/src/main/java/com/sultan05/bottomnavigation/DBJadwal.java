package com.sultan05.bottomnavigation;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class DBJadwal extends SQLiteOpenHelper {

    //InnerClass, untuk mengatur artibut seperti Nama Tabel, nama-nama kolom dan Query
    static abstract class MyColumns implements BaseColumns {
        //Menentukan Nama Table dan Kolom
        static final String NamaTabel = "Jadwal";

//        static final String KEY_ID = "_id";
        static final String Hari = "hari";
        static final String Jam = "jam";
        static final String Kelas = "kelas";
        static final String Ruang = "ruang";
        static final String Mapel = "mapel";
    }

    private static final String NamaDatabse = "jadwal.db";
    private static final int VersiDatabase = 1;
//+MyColumns.KEY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
    //Query yang digunakan untuk membuat Tabel
    private static final String SQL_CREATE_ENTRIES = "CREATE TABLE "+MyColumns.NamaTabel+
            "("
            +MyColumns.Hari+" TEXT NOT NULL, "
            +MyColumns.Jam+" TEXT NOT NULL, "
            +MyColumns.Kelas+" TEXT NOT NULL,  "
            +MyColumns.Ruang+" TEXT NOT NULL, "
            +MyColumns.Mapel+" TEXT NOT NULL)";

    //Query yang digunakan untuk mengupgrade Tabel
    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS "+MyColumns.NamaTabel;

    public DBJadwal(Context context) {
        super(context, NamaDatabse, null, VersiDatabase);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}