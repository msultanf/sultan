package com.sultan05.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class detailJadwal extends AppCompatActivity {

    String ambilHari, ambilJam, ambilKelas, ambilRuang, ambilMapel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_jadwal);

        TextView detail_h = findViewById(R.id.detail_hari);
        TextView detail_j = findViewById(R.id.detail_jam);
        TextView detail_k = findViewById(R.id.detail_kelas);
        TextView detail_r = findViewById(R.id.detail_ruang);
        TextView detail_m = findViewById(R.id.detail_mapel);

        Bundle bundle = getIntent().getExtras();
        //mengambil data dari recyclerViewAdapter
        ambilHari =bundle.getString("hariList");
        detail_h.setText(ambilHari);
        ambilJam = bundle.getString("jamList");
        detail_j.setText(ambilJam);
        ambilKelas = bundle.getString("kelasList");
        detail_k.setText(ambilKelas);
        ambilRuang = bundle.getString("ruangList");
        detail_r.setText(ambilRuang);
        ambilMapel = bundle.getString("mapelList");
        detail_m.setText(ambilMapel);
    }
}
