package com.sultan05.bottomnavigation;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.android.material.snackbar.Snackbar;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.Executor;

import static android.text.TextUtils.isEmpty;
import static androidx.core.content.ContextCompat.getSystemService;
//import static com.sultan05.bottomnavigation.DBJadwal.MyColumns.KEY_ID;


public class Input extends Fragment {
    Spinner s_kelas, s_ruang, s_mapel, s_jam, s_hari;
    Button btn_save;
//
//    String a = KEY_ID;
//    int id = Integer.parseInt(a);

    //variabel untuk menyimpan input dari user
    private String setId, setKelas, setRuang, setMapel, setJam, setHari;
    //variabel untuk inisialisasi database
    private DBJadwal dbJadwal;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_input, container, false);
        //Inisialisasi dan Mendapatkan Konteks dari DBMahasiswa
        dbJadwal = new DBJadwal(getActivity().getBaseContext());
        // inisialisasi
        btn_save = (Button) rootView.findViewById(R.id.btn_save);
        s_hari = (Spinner) rootView.findViewById(R.id.spinner_hari);
        s_jam = (Spinner) rootView.findViewById(R.id.spinner_jam);
        s_kelas = (Spinner) rootView.findViewById(R.id.spinner_kelas);
        s_ruang = (Spinner) rootView.findViewById(R.id.spinner_ruang);
        s_mapel = (Spinner) rootView.findViewById(R.id.spinner_mapel);

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setData();
                saveData();
                Toast.makeText(getActivity().getApplicationContext(),"Data Berhasil Disimpan", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

    //Berisi Statement-Statement Untuk Mendapatkan Input Dari User
    private void setData(){
        setHari = s_hari.getSelectedItem().toString();
        setJam = s_jam.getSelectedItem().toString();
        setKelas = s_kelas.getSelectedItem().toString();
        setRuang = s_ruang.getSelectedItem().toString();
        setMapel = s_mapel.getSelectedItem().toString();
    }
    //Berisi Statement-Statement Untuk Menyimpan Data Pada Database
    private void saveData(){
        //Mendapatkan Repository dengan Mode Menulis
        SQLiteDatabase create = dbJadwal.getWritableDatabase();
        //Membuat Map Baru, Yang Berisi Nama Kolom dan Data Yang Ingin Dimasukan
        ContentValues values = new ContentValues();
//        values.put(KEY_ID, id++);
        values.put(DBJadwal.MyColumns.Hari, setHari);
        values.put(DBJadwal.MyColumns.Jam, setJam);
        values.put(DBJadwal.MyColumns.Kelas, setKelas);
        values.put(DBJadwal.MyColumns.Ruang, setRuang);
        values.put(DBJadwal.MyColumns.Mapel, setMapel);

        //Menambahkan Baris Baru, Berupa Data Yang Sudah Diinputkan pada Kolom didalam Database
        create.insert(DBJadwal.MyColumns.NamaTabel, null, values);
    }
}
