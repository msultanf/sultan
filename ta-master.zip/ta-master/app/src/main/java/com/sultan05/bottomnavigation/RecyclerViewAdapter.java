package com.sultan05.bottomnavigation;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//import static com.sultan05.bottomnavigation.DBJadwal.MyColumns.KEY_ID;
import static com.sultan05.bottomnavigation.DBJadwal.MyColumns.Kelas;

//Class Adapter ini Digunakan Untuk Mengatur Bagaimana Data akan Ditampilkan
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

private ArrayList<Jadwalmodel> dataList;
public RecyclerViewAdapter(ArrayList<Jadwalmodel> dataList){
    this.dataList = dataList;
}

    //ViewHolder Digunakan Untuk Menyimpan Referensi Dari View-View
    class ViewHolder extends RecyclerView.ViewHolder{

        private TextView Hari, Jam, Kelas, Ruang, Mapel;
        private RelativeLayout itemList;
        ImageButton Overflow;
        ViewHolder(View itemView) {
            super(itemView);

            //Mendapatkan Context dari itemView yang terhubung dengan Activity ViewData
            Context context = itemView.getContext();

            //Menginisialisasi View-View untuk kita gunakan pada RecyclerView
//            NIM = itemView.findViewById(R.id.NIM);
            itemList = itemView.findViewById(R.id.item_list);
            Hari = itemView.findViewById(R.id.hari);
            Jam = itemView.findViewById(R.id.jam);
            Kelas = itemView.findViewById(R.id.kelas);
            Ruang = itemView.findViewById(R.id.ruang);
            Mapel = itemView.findViewById(R.id.mapel);
            Overflow = itemView.findViewById(R.id.overflow);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //Membuat View untuk Menyiapkan dan Memasang Layout yang Akan digunakan pada RecyclerView
        View V = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_design, parent, false);
        return new ViewHolder(V);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        //Memanggil Nilai/Value Pada View-View Yang Telah Dibuat pada Posisi Tertentu
        //Mengambil data (Nama) sesuai dengan posisi yang telah ditentukan
//        final String nim1 = dataList.get(position).getNimList();
        final String hari1 = dataList.get(position).getHariList();
        final String jam1 = dataList.get(position).getJamList();
        final String Kelas1 = dataList.get(position).getKelasList();
        final String Ruang1 = dataList.get(position).getRuangList();
        final String Mapel1 = dataList.get(position).getMapelList();

//        holder.NIM.setText(nim1);
        holder.Hari.setText(hari1);
        holder.Jam.setText(jam1);
        holder.Kelas.setText(Kelas1);
        holder.Ruang.setText(Ruang1);
        holder.Mapel.setText(Mapel1);
        holder.itemList.findViewById(R.id.item_list);
        holder.itemList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), detailJadwal.class);
                i.putExtra("hariList", hari1);
                i.putExtra("jamList", jam1);
                i.putExtra("kelasList", Kelas1);
                i.putExtra("ruangList", Ruang1);
                i.putExtra("mapelList", Mapel1);

                v.getContext().startActivity(i);
            }
        });

        //Mengimplementasikan Menu Popup pada Overflow (ImageButton)
        holder.Overflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                //Membuat Instance/Objek dari PopupMenu
                PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
                popupMenu.inflate(R.menu.popup_menu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.delete:
                                //Menghapus Data Dari Database
                                DBJadwal getDatabase = new DBJadwal(view.getContext());
                                SQLiteDatabase DeleteData = getDatabase.getWritableDatabase();
                                //Menentukan di mana bagian kueri yang akan dipilih
                                String selection = Kelas + " LIKE ?";
                                //Menentukan Nama Dari Data Yang Ingin Dihapus
                                String[] selectionArgs = {Kelas};
                                DeleteData.delete(DBJadwal.MyColumns.NamaTabel, selection, selectionArgs);

                                //Menghapus Data pada List dari Posisi Tertentu
                                String position2 = String.valueOf(Kelas.indexOf(Kelas));
                                dataList.remove(position);
                                notifyItemRemoved(position);
                                if (position2 == null) {
                                    notifyItemRangeChanged(Integer.parseInt(position2), dataList.size());
                                }
                                break;

                            case R.id.update:
                                Intent dataForm = new Intent(view.getContext(), UpdateActivity.class);
                                dataForm.putExtra("SendNIM", Kelas);
                                view.getContext().startActivity(dataForm);
                                ((Activity)view.getContext()).finish();
                                break;
                        }
                        return true;
                    }
                });
                popupMenu.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        //Menghitung Ukuran/Jumlah Data Yang Akan Ditampilkan Pada RecyclerView
        return dataList.size();
    }
//    void setFilter(ArrayList<Jadwalmodel> filterList){
//        dataList = new ArrayList<>();
//        dataList.addAll(filterList);
//        notifyDataSetChanged();
//    }

}
