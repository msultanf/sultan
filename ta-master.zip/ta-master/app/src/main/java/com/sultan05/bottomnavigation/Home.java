package com.sultan05.bottomnavigation;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Home extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_home, container, false);
        ImageView logo_smk = (ImageView) view.findViewById(R.id.logo_smk);
        logo_smk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.logo_smk:
                        Intent iStore = new Intent(Intent.ACTION_VIEW);
                        iStore.setData(Uri.parse("http://www.smkn1-sby.sch.id/"));
                        startActivity(iStore);
                        break;
                }
            }
        });
        return view;
    }
}
