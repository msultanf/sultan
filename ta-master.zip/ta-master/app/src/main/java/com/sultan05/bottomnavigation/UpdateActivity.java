package com.sultan05.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    private DBJadwal MyDatabase;
    private Spinner NewHari, NewJam, NewKelas, NewRuang, NewMapel;
    private EditText NewNIM;
    private String getNewNIM, getNewHari, getNewJam, getNewKelas, getNewRuang, getNewMapel;
    private Button NewSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        MyDatabase = new DBJadwal(getBaseContext());
        NewHari = findViewById(R.id.new_spinner_hari);
        NewJam = findViewById(R.id.new_spinner_jam);
        NewKelas = findViewById(R.id.new_spinner_kelas);
        NewRuang = findViewById(R.id.new_spinner_ruang);
        NewMapel = findViewById(R.id.new_spinner_mapel);
        NewSave = findViewById(R.id.new_btn_save);
        NewSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setUpdateData();
                startActivity(new Intent(UpdateActivity.this, Jadwal.class));
                finish();
            }
        });
    }

    private void setUpdateData(){
        getNewNIM = NewNIM.getText().toString();
        getNewHari = NewHari.getSelectedItem().toString();
        getNewJam = NewJam.getSelectedItem().toString();
        getNewKelas = NewKelas.getSelectedItem().toString();
        getNewRuang = NewRuang.getSelectedItem().toString();
        getNewMapel = NewMapel.getSelectedItem().toString();

        //Menerima Data NIM yang telah dipilih Oleh User untuk diposes
        String GetNIM = getIntent().getExtras().getString("SendNIM");

        SQLiteDatabase database = MyDatabase.getReadableDatabase();

        //Memasukan Data baru pada 3 kolom (NIM, Nama dan Jurusan)
        ContentValues values = new ContentValues();
//        values.put(DBJadwal.MyColumns.NIM, getNewNIM);
        values.put(DBJadwal.MyColumns.Hari, getNewHari);
        values.put(DBJadwal.MyColumns.Jam, getNewJam);
        values.put(DBJadwal.MyColumns.Kelas, getNewKelas);
        values.put(DBJadwal.MyColumns.Ruang, getNewRuang);
        values.put(DBJadwal.MyColumns.Mapel, getNewMapel);

        //Untuk Menentukan Data/Item yang ingin diubah, berdasarkan NIM
        String selection = DBJadwal.MyColumns.Kelas + " LIKE ?";
        String[] selectionArgs = {GetNIM};
        database.update(DBJadwal.MyColumns.NamaTabel, values, selection, selectionArgs);
        Toast.makeText(getApplicationContext(), "Berhasil Diubah", Toast.LENGTH_SHORT).show();
    }
}